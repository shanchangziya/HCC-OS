Manuscript OSARS

128 genes, StepCox[forward] + GBM, 1,696 trees.
Run from the extracted directory with Python 3:

python3 score_osars.py frozen_osars128 example_input.csv example_scores.csv

Compare against example_expected.csv. For real inputs use the preprocessing
described in Supplementary Data 4 and at:
https://github.com/shanchangziya/HCC-OS/tree/main/revision/manuscript_osars128
